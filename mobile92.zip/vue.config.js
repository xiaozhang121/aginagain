module.exports = {
  lintOnSave: false,
  devServer: {
    open: true,
    port: '12233'
  }
}
