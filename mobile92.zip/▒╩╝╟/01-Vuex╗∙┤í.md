# Vuex



## 组件之间传值回看

### 兄弟之间

![1573222656185](img(online)/1573222656185.png)

实现步骤：

1. 定义模块 src/bus.js，内容就是**导入**Vue模块并**导出**一个Vue实例对象

   ```js
   import Vue from 'vue'
   export default new Vue() 
   ```

   

2. 在各个兄弟组件中，导入 bus.js 模块

   ```js
   import bus from '@/bus.js'
   ```

   > 虽然bus.js被各个组件都导入，但是系统中bus只有一份

3. 在**接收**数据的兄弟组件的 created 生命周期方法里(使得事件及时响应)，"大哥"的组件中声明

   使用 bus.$on('事件名称', (接收的数据) => {}) 定义事件成员方法

   ```js
   created(){
     // 定义事件,注意箭头函数应用
     bus.$on('xxx', data=>{
       console.log(data)
     })
   }
   ```

   > xxx是事件方法的名称
   >
   > data是形参，待接收数据，并且可以定义多个
   >
   > 注意：如果$on内部要使用this，请通过"**箭头函数**"声明方法

4. 在**发送**数据的兄弟组件中，使用 bus.$emit('事件名称', 要发送的数据) 来向外发送数据

   ```js
   <button @click="sendMsg">给兄弟说话</button>
   export default {
     methods: {
       sendMsg(){
         // 触发 绑定的 事件，并向外传递参数
         bus.$emit('xxx', '1000元保护费')
       }
     }
   }
   ```

   > xxx 是接收数据组件给bus声明的方法





### 父给子

父组件要在子组件标签上通过**属性值**方式传值

```html
<子组件标签 name=value name=value name=value></子组件标签>
```

子组件接收并应用父传递来的数据，具体通过props接收

```html
<!--在模板中应用传递来的数据-->
<input :style="{color:xx}">

<script>
  export default {
    // 通过props接收父传递过来的数据,注意各个名称需要使用单引号圈选
    props:['xx','xx','xx'],
    props:{
      xx:{
        type:类型限制
        default:默认值
      }
    }
  }
</script>
```



### 子给父

**`父组件操作语法`**：

父组件通过**@符号**向子组件传递一个<font color=red>事件方法</font>

```
<子组件 @func1="show"></子组件>
...
methods:{
	show(arg1,arg2){xxxx}
}
```

其中

​	func1为事件的名称，给子组件触发使用

​	show为该事件的执行函数，在父组件内部的methods中定义好

​	在事件中可以通过形参(arg1、arg2)接收子组件出来过来的数据 并做近一步处理



**`子组件操作`**：

子组件中，使用<font color=red>this.$emit()</font>调用 父组件中的方法

```js
this.$emit('func1', 数据, 数据)
this:当前子组件对象
$emit:通过这个关键字可以使得子组件可以调用 父组件 的事件
```

从第二个位置开始传递实参数据，其可以被父组件methods方法的形参所接受

$emit(名称，数据，数据……) 是组件调用自己方法的固定方式，第一个参数是被调用方法的名称，后续参数都是给方法传递的实参信息



## 什么是Vuex

官网：https://vuex.vuejs.org/zh/

 

Vuex 是一个专为 Vue.js 应用程序开发的  数据状态管理模式。

它采用集中式存储管理应用中  所有组件的共享数据



Vuex是组件之间数据共享的一种机制

![1581065897149](img(online)/1581065897149.png)

 

## 为什么要有Vuex

父子传值或兄弟传值，太麻烦了，不好管理

vuex提供了一种全新的数据共享管理模式，该模式相比较简单的组件传值更加高端、大气、上档次。

 

`注意`：

1. 只有组件间共享的数据，才有必要存储到vuex中，组件自己私有的数据，还是要存储到自己的data中；

2. 在应用的时候要因地制宜，普通组件传值  和  vuex 适合应用在不同场合，要注意区分

 

# 初始化

## 初始化项目

创建一个新vuecli 项目： vue  create  01-pro

![1581211435907](img(online)/1581211435907.png)

现在的vuecli脚手架项目的**eslint依赖包**有升级，该套依赖包对vscode版本有要求

如果发现eslint自动规范格式化不灵了，请做如下操作

1. 到官网下载最新版本的vscode(1.42.0)，安装(卸载之前旧版本的vscode编辑器)

   (不用担心，之前vscode的相关扩展还依然存在)

2. 给vscode把之前的eslint扩展给卸载了，安装最新版的(2.0.15)





`配置`：

1. 给项目做配置vue.config.js

   ```js
   module.exports = {
     lintOnSave: false,
     devServer: {
       open: true
     }
   }
   
   ```

2. 删除components/HelloWorld.vue文件

3. 初始化App.vue文件，内容如下：

   ```vue
   <template>
       <div>
         <h2>App根基组件</h2>
       </div>
   </template>
   
   <script>
   export default {
     name: 'App'
   }
   </script>
   
   <style lang="less" scoped>
   </style>
   
   ```

4. 执行命名： npm run serve 启动项目



`效果`：

![1580612250804](img(online)/1580612250804.png)

  

## 创建应用组件

`步骤`：

1. 在src/components 下创建两个应用组件First.vue 和 Second.vue，并填充如下内容

   First.vue

   ```vue
   <template>
       <div id="first">
         <p>我是大哥组件</p>
       </div>
   </template>
   
   <script>
   export default {
     name: 'first'
   }
   </script>
   
   <style lang="less" scoped>
   #first{
     width: 350px;
     height: 200px;
     border:2px solid blue;
   }
   </style>
   
   ```

   Second.vue

   ```vue
   <template>
       <div id="second">
         <p>我是小弟组件</p>
       </div>
   </template>
   
   <script>
   export default {
     name: 'second'
   }
   </script>
   
   <style lang="less" scoped>
   #second{
     width: 350px;
     height: 200px;
     border:2px solid green;
     margin-top:10px;
   }
   </style>
   
   ```

2. App.vue对First.vue 和 Second.vue 做  导入、注册、使用

   ```vue
   <template>
       <div id="app">
         <h2>App根组件-Vuex</h2>
         <first></first>
         <second></second>
       </div>
   </template>
   
   <script>
   import First from './components/First'
   import Second from './components/Second'
   export default {
     name: 'app',
     components: {
       First,
       Second
     }
   }
   </script>
   
   <style lang="less" scoped>
   #app{
     width: 400px;
     height: 600px;
     border:2px solid red;
   }
   </style>
   
   ```



访问效果：

![1581060679725](img(online)/1581060679725.png)



## 初始化vuex

1. 安装vuex

   ```bash
   npm i vuex
   ```

   

2. main.js做如下设置

   ```js
   import Vue from 'vue'
   import App from './App.vue'
   // 使用Vuex
   // 1. 导入vuex模块
   import Vuex from 'vuex'
   
   // 2. Vue对Vuex进行注册
   //    之后再组件内部就可以使用vuex的相关成员了
   //    Vue.prototype.$store = xxx
   Vue.use(Vuex) // 插件 应用
   
   // 3. 实例化vuex对象，并做具体配置
   //    new Vuex.Store() 是固定用法
   //    store：名字暂时是固定的，因为后续对其有使用
   const store = new Vuex.Store({
     // state:固定标志，给Vuex配置"共享数据"，通过对象成员体现
     state: {
       // 具体数据，数据名称可以自定义，数量不限制
       count: 25,
       count1: 26
       // ……
     }
   })
   
   Vue.config.productionTip = false
   
   new Vue({
     // 4. 对vuex进行挂载
     store, // 简易成员赋值，store:store
     render: h => h(App)
   }).$mount('#app')
   
   ```
   



# 使用Vuex

## 访问

### state

`目标`：

​	在各个组件中访问vuex共享的数据

`语法`：

```js
this.$store.state.xxx   	// 组件内
$store.state.xxx 				// 模板中
```

> xxx：代表共享数据的名称



`操作`：

给First.vue设置如下代码

```vue
<template>
    <div id="first">
      <p>我是大哥组件</p>
      <p>count的值为：{{$store.state.count}}</p>
    </div>
</template>
```



给Second.vue 设置如下代码：

```vue
<template>
    <div id="second">
      <p>我是小弟组件</p>
      <p>count的值为：{{$store.state.count}}</p>
    </div>
</template>
```



`效果`：

![1581060982467](img(online)/1581060982467.png)

`注意`：

​	vuex数据既可以在模板中被访问，语法 **$store.state.xxx**

​	也可以在组件实例内部被访问，语法 **this.\$store.state.xxx**

 

### mapState

`目标`：

​	掌握  mapState  方式访问state成员



`引言`：

​	组件中的Vuex数据如果需要频繁被访问，那么类似这样的代码  this.$store.state.xxx 或 \$store.state.xxx 需要被重复编写，显然，这个代码有点过于复杂，会增加很多工作量，有没有简便的方式处理呢? 答：可以使用mapState



使用步骤

1. 在应用组件里边   按需导入 mapState 辅助函数

   ```js
   import { mapState } from "vuex";
   ```

   

2. 定义计算属性

   ```js
   computed: {
   	// 通过 展开运算符，把 state中的数据映射为计算属性
     ...mapState([xx,yy,zz……])
   }
   
   // mapState函数本质为如下：
   /*
   function mapState(arr){
     return {
       arr[0]:function(){
         return this.$store.state.arr[0]
       },
       arr[1]:function(){
         return this.$store.state.arr[1]
       }
       ……
     }
   }
   */
   
   ```

   

3. 现在在组件中就可以像访问data一样访问Vuex成员了



使用示例：

在Second.vue组件中通过mapState方式设置并访问共享数据：

```vue
<template>
    <div id="second">
      <p>我是小弟组件</p>
      <p>count的值为：
        <!--类似访问普通data成员一样，访问vuex数据-->
        {{count}}--
        {{count}}--
        {{count1}}--
        {{count1}}--
      </p>
    </div>
</template>

<script>
// 通过mapState对共享数据做简化获取处理
import { mapState } from 'vuex'
export default {
  name: 'second',
  // 计算属性
  computed: {
    // 处理mapState，三个点是做展开运算的，运算结果与后边的内容是一致的
    ...mapState(['count', 'count1'])
    // 通过mapState对下述成员做简化处理
    // count: function () {
    //   return this.$store.state.count
    // },
    // count1: function () {
    //   return this.$store.state.count1
    // }
  }
}
</script>
```

> ...mapState(['count']) 是做展开操作，获得类似如下的函数
>
> count: function () { 
>
> ​	return this.$store.state.count
>
> }

> 如果有多个成员都要经过mapState配置，可以这样 ...mapState([xx,yy,zz])



`效果`：

![1581216183855](img(online)/1581216183855.png)



`注意`：

​	mapState是把共享数据配置为**computed计算属性**的成员了	 

 

## 修改(同步)

修改store中state上的值，需要借助mutations

### mutations

`目标`：

​	通过mutations对state共享数据进行修改



`声明语法`：

```js
// 在实例化Vuex对象的参数对象中，定义mutations成员(与state平级)对象
mutations:{
 	// 参数state是固定的，代表vuex本身的state(名称可以自定义，为了可读性就用state即可)，
  // 可以用以获取其中的共享数据
  // 第二个参数可以接收 应用层 参数信息
	方法名称(state,形参){
		通过state修改内部的数据
	}
}
```

 

`调用 mutations 语法`：

```js
// 组件实例调用
this.$store.commit('mutations方法名')
this.$store.commit('mutations方法名',实参)
// 模板中调用
$store.commit('mutations方法名')  
$store.commit('mutations方法名',实参)
```



使用示例：

1. 给vuex声明mutations和相关成员

   ```js
   // mutations:固定标志，对共享数据做修改操作
   mutations: {
     // 声明修改数据的各个方法
     // mod是自定义名称
     // 参数state，可以自定义，但是就用state，可读性好，意思固定，就代表内部state对象成员(但是它们不是同一个对象)
     // 参数data，是自定义的，可以接收应用层的数据信息
     mod: function (state, data) {
       // 对共享数据最修改
       state.count += data
     }
   }
   ```

   

2. 在First.vue中调用mutations成员

   ```vue
   <template>
     <div id="first">
       <p>我是大哥组件</p>
       <p>count的值为：{{$store.state.count}}</p>
       <p>
         <button @click="$store.commit('mod', 10)">修改count</button>
         <button @click="$store.commit('mod', 20)">修改count</button>
         <button @click="$store.commit('mod', 30)">修改count</button>
       </p>
     </div>
   </template>
   ```
   
> 在组件实例内部 可以 通过this调用，例如 this.$store.commit('mod',10)
   >
   > 调用一次或多次都可以



`效果`：

![1581217106116](img(online)/1581217106116.png)

`注意`：

​	不要对this.$store.state.xxx 直接修改，容易造成数据混乱，因为许多组件都可以这样干



### mapMutations

组件中的Vuex数据如果需要频繁被修改，那么类似这样的代码 this.$store.commit(xxx,yyy) 需要被重复编写，显然，这个代码有点过于复杂，会增加很多工作量，有没有简便的方式处理呢? 答：可以使用mapMutations



`使用步骤`：

1. 在应用组件中做mapMutations 的模块化导入操作

   ```js
   import { mapMutations } from "vuex";
   ```

   

2. 在methods方法中做如下设置

   ```js
   methods: {
     ...mapMutations([xx,yy,zz……])
   }
   
   // mapMutations 函数本质为如下：
   /*
   function mapMutations(arr){
     return {
       arr[0]:function(arg){
         return this.$store.commit(arg)
       },
       arr[1]:function(arg){
         return this.$store.commit(arg)
       }
       ……
     }
   }
   */
   
   ```

   > 注意：
   >
   > ​	mapState 是在computed中做展开
   >
   > ​	mapMutations是在methods中做展开
   >
   > ​	xx/yy/zz 是mutations成员名称，一个或多个都可以

3. 现在可以像访问methods方法一样直接访问mutations成员了





应用示例：

在Second.vue中做如下配置：

```vue
<template>
  <div id="second">
    <p>我是小弟组件</p>
    <p>
      count的值为：
      <!--类似访问普通data成员一样，访问vuex数据-->
      {{count}}--
      {{count}}--
      {{count1}}--
      {{count1}}--
    </p>
    <p>
      <!-- 如下代码冗余度很高 -->
      <!-- <button @click="$store.commit('mod', 10)">修改count</button>
      <button @click="$store.commit('mod', 20)">修改count</button>
      <button @click="$store.commit('mod', 30)">修改count</button> -->
      <!-- 用简便方式实现数据修改   mapMutations
           就让mutations方法转变为自己的methods方法了
      -->
      <button @click="mod(10)">修改count</button>
      <button @click="mod(20)">修改count</button>
      <button @click="mod(30)">修改count</button>
    </p>
  </div>
</template>

<script>
// 通过mapState对共享数据做简化获取处理
import { mapState, mapMutations } from 'vuex'
export default {
  name: 'second',
  // 计算属性
  computed: {
    // 处理mapState，三个点是做展开运算的，运算结果与后边的内容是一致的
    ...mapState(['count', 'count1'])
    // 通过mapState对下述成员做简化处理
    // count: function () {
    //   return this.$store.state.count
    // },
    // count1: function () {
    //   return this.$store.state.count1
    // }
  },
  methods: {
    // 应用mapMutations
    ...mapMutations(['mod'])
    // 最终要通过 mapMutations 获得如下相关的方法
    // mod (arg) {
    //   this.$store.commit('mod', arg)
    // }
  }
}
</script>
```

> ...mapMutations(['mod']) 做展开操作，获得类似如下的函数
>
> mod: function (arg) { 
>
> ​	return this.$store.commit('mod',arg)
>
> }



执行效果：

![1581218819304](img(online)/1581218819304.png)



## 修改(异步)

mutations 和 actions 两个项目都是对Vuex的共享数据最修改的它们的区别是：

mutations用在同步数据操作上

actions用在异步数据修改操作上



什么地方有异步操作：

1. ajax/axios
2. setTimeout
3. fs.readFile()
4. ……



`声明语法`：

```js
// actions:固定标志，对共享数据做异步修改
actions: {
  // 声明修改数据的成员方法，数量不限制
  // 参数context：可以自定义，但是就用context(官方就用之)，是一个对象，
  // 具体代表$store(它们不是同一个对象)
  // 参数data：可以自定义名称，用于可以接收应用层的数据信息
  成员名称: function (context, data) {
    // actions规定要通过调用mutations成员修改数据(vuex内部规定的)
    context.commit(mutations成员，实参)
  }
}
```



`调用语法`：

```js
this.$store.dispatch('xx',参数)  // 组件内部
$store.dispatch('xx',参数)  // 模板
```

> xx:代表actions内部成员名称

 



### actions

`目标`：

​	通过actions实现异步方式修改vuex的数据信息



`步骤`：

1.  在vuex中通过actions声明成员，实现异步修改数据操作

   ```js
   actions: {
       xiu: function (context, data) {
         // 通过setTimeout实现“异步”请求，定时1s后执行
         setTimeout(() => {
           context.commit('mod', data)
         }, 1000)
       }
   }
   ```

   > 请求过来后停顿1秒后再操作，体现异步

   

2. First.vue中调用actions方法

   ```vue
   <p>
     <button @click="$store.dispatch('xiu',10)">异步修改count</button>
     <button @click="$store.dispatch('xiu',20)">异步修改count</button>
     <button @click="$store.dispatch('xiu',30)">异步修改count</button>
   </p>
   ```



`效果`：

![1581219934577](img(online)/1581219934577.png)



注意：

​	actions成员内部 既可以操作mutations成员，也可以操作 state成员

​	一般不要操作 state，所有数据修改都通过mutations进行，尽管这样有点繁琐，

​	但是好处是数据管理比较集中、专业，体现了只有mutations才拥有修改数据的特权。



### mapActions

组件中的Vuex数据需要频繁被修改，那么类似这样的代码 this.$store.dispatch(xxx) 需要被重复编写，显然，这个代码有点过于复杂，会增加很多工作量，有没有简便的方式处理呢? 答：可以使用mapActions

 

`使用步骤`：

1. 在应用组件中做mapActions 的模块化导入操作

   ```js
     import { mapActions } from "vuex";
   ```

   

2. 在methods方法中做如下设置

   ```js
   import { mapActions } from "vuex";
   methods: {
   	...mapActions([xx,yy,zz])
   }
   // mapActions 函数本质为如下：
   /*
   function mapActions(arr){
     return {
       arr[0]:function(arg){
         return this.$store.dispatch(arg)
       },
       arr[1]:function(arg){
         return this.$store.dispatch(arg)
       }
       ……
     }
   }
   */
   
   ```

   > 注意：
   >
   > ​	mapActions是在methods中做展开
   >
   > ​	xx/yy/zz 是actions成员名称，一个或多个都可以

3. 现在可以像访问methods方法一样访问actions成员了





应用示例：

Second.vue中设置如下代码：

```vue
<template>
  <div id="second">
    <p>我是小弟组件</p>
    <p>
      count的值为：
      <!--类似访问普通data成员一样，访问vuex数据-->
      {{count}}--
      {{count}}--
      {{count1}}--
      {{count1}}--
    </p>
    <p>
      <!-- 如下代码冗余度很高 -->
      <!-- <button @click="$store.commit('mod', 10)">修改count</button>
      <button @click="$store.commit('mod', 20)">修改count</button>
      <button @click="$store.commit('mod', 30)">修改count</button> -->
      <!-- 用简便方式实现数据修改   mapMutations
           就让mutations方法转变为自己的methods方法了
      -->
      <button @click="mod(10)">修改count</button>
      <button @click="mod(20)">修改count</button>
      <button @click="mod(30)">修改count</button>
    </p>
    <p>
      <!--
        <button @click="$store.dispatch('xiu',10)">修改(异步)count</button>
        <button @click="$store.dispatch('xiu',20)">修改(异步)count</button>
        <button @click="$store.dispatch('xiu',30)">修改(异步)count</button>
      -->
      <!-- 异步方式修改数据
          用简便方式实现，像调用methods方法一样，去调用actions成员
      -->
      <button @click="xiu(10)">修改(异步)count</button>
      <button @click="xiu(20)">修改(异步)count</button>
      <button @click="xiu(30)">修改(异步)count</button>
    </p>
  </div>
</template>

<script>
// 通过mapState对共享数据做简化获取处理
import { mapState, mapMutations, mapActions } from 'vuex'
export default {
  name: 'second',
  // 计算属性
  computed: {
    // 处理mapState，三个点是做展开运算的，运算结果与后边的内容是一致的
    ...mapState(['count', 'count1'])
    // 通过mapState对下述成员做简化处理
    // count: function () {
    //   return this.$store.state.count
    // },
    // count1: function () {
    //   return this.$store.state.count1
    // }
  },
  methods: {
    // 应用mapMutations
    ...mapMutations(['mod']),
    // 最终要通过 mapMutations 获得如下相关的方法
    // mod (arg) {
    //   this.$store.commit('mod', arg)
    // }

    // actions成员越多，越能体现mapActions的优势
    ...mapActions(['xiu'])
    // 上述语句会生成下述函数
    // xiu (arg) {
    //   // 执行动作不需要return
    //   // 要获得返回值才需要return
    //   this.$store.dispatch('xiu', arg)
    // }
  }
}
</script>
```

 

`效果`：

![1581220674246](img(online)/1581220674246.png)



`注意`：

​	mutations也可以实现异步方式操作数据，为什么不这样做呢

 	1. devtools调试工具有延迟，造成调试有误差
 	2. 比较混乱，不成规矩
 	3. Vuex倡导者也不推荐这样干



![1581164488416](img(online)/1581164488416.png)

上图来自官网，说明的事情有如下：

1. Actions拥有与后端接口直接交互的特权，一般都是**异步**操作
2. Actions对mutations进行调用，调用 commit
3. mutations的操作可以直观反映在devtools调试工具中，方便程序调试
4. mutations对state进行直接操作
5. state状态数据可以渲染给组件显示
6. 组件实例通过 dispatch 调用actions





上午总结：

1. vuex 共享数据
2. 初始化  安装(npm i vuex)   main.js  4个步骤(导入、注册、创建对象、挂载)
3. vuex对象核心：state(共享数据)、mutations(修改-同步)、actions(修改-异步)
4. state操作   **this.$store.state.xxx**
   1. mapState---->computed      data
5. mutations操作  **this.$store.commit(方法名称，实际参数)**
   1. mapMutations---->methods
   2. 声明  mutations:{mod:function(state,data){state.xxxx}}
6. actions操作   **this.$store.dispatch(方法名称，实际参数)**
   1. mapActions---->methods
   2. 声明actions:  actioins:{xiu:function(context,data){  context.commit(mutations方法，data)  }}



# 案例应用

`目标`：

​	通过vuex实现对账户信息的管理维护



## 介绍

案例描述：

​	一般后台项目应用中，用户输入 用户名、密码 登录系统，此时服务器端做账号有效性校验，并使得用户进入后台系统，后台系统中有许多组件对用户的信息都要进行操作，有的组件要显示用户的相关信息，有的组件要判断用户信息是否存在并做不同处理，有的组件要删除用户的信息，因此用户在进入系统的同时还要通过localStorage存储账号信息，以便各组件获取使用。

​	

## 实操

### 创建vuecli项目

![1581130307882](img(online)/1581130307882.png)

路由、Vuex都默认安装

### 项目结构文件初始化

1. 给项目做配置

   vue.config.js

   ```js
   module.exports = {
     lintOnSave: false,
     devServer: {
       open: true
     }
   }
   
   ```

2. 删除views/About.vue文件

3. 删除router/index.js 中About对应的路由

4. 创建views/Login.vue文件、并创建对应路由

   ```vue
   <template>
       <div>
         <h2>管理员登录</h2>
       </div>
   </template>
   
   <script>
   export default {
     name: 'home'
   }
   </script>
   
   <style lang="less" scoped>
   </style>
   
   ```

   ```js
   {
     path: '/login',
     name: 'login',
     component: () => import('@/views/Login.vue')
   }
   ```

5. 初始化views/Home.vue 内容

   ```vue
   <template>
       <div>
         <h2>后台首页</h2>
       </div>
   </template>
   
   <script>
   export default {
     name: 'home'
   }
   </script>
   
   <style lang="less" scoped>
   </style>
   
   ```

   

6. 初始化App.vue文件，内容如下：

   ```vue
   <template>
       <div>
         <router-view></router-view>
       </div>
   </template>
   
   <script>
   export default {
     name: 'app'
   }
   </script>
   
   <style lang="less" scoped>
   </style>
   
   ```

7. 执行命名： npm run serve 启动项目



![1581229750614](img(online)/1581229750614.png)

### 绘制登录页面完成登录功能

在views/Login.vue 中做如下设置

```vue
<template>
    <div>
      <form action="sss">
          <p>用户名：<input type="text" v-model.trim="loginForm.username"></p>
          <p>密码：<input type="password" v-model.trim="loginForm.userpass"></p>
          <p><button @click.prevent="login()">登录</button></p>
      </form>
    </div>
</template>

<script>
export default {
  name: 'login',
  data () {
    return {
      loginForm: {
        username: '',
        userpass: ''
      }
    }
  },
  methods: {
    login () {
      if (this.loginForm.username && this.loginForm.userpass) {
        this.$router.push({ name: 'home' })
      }
    }
  }
}
</script>

<style lang="less" scoped>
</style>

```

> v-model.trim  ：修饰器，使得获得内容的左右空格自动清除
>
> ​							相关说明  https://vue.docschina.org/v2/guide/forms.html#trim 
>
> @click.prevent：事件修饰符，阻止浏览器默认动作，阻止form表单的跳转动作



### 后台首页布局展示

在views/Home.vue 中设置如下内容：

```vue
<template>
  <div>
    <div id="head">
    </div>
    <div id="zhanghu"></div>
  </div>
</template>

<script>
export default {
  name: 'home'
}
</script>

<style lang="less" scoped>
#head {
  width: 100%;
  height: 100px;
  background-color: lightgreen;
}
#zhanghu {
  width: 100%;
  height: 260px;
  background-color: lightblue;
}
</style>

```

`效果`：

![1581150495543](img(online)/1581150495543.png)

### localStorage介入

`目标`：

​	用户登录系统后，本身的账号信息通过localStorage存储，以便业务组件访问



在views/Login.vue的登录方法中设置如下代码：

```js
login () {
  if (this.loginForm.username && this.loginForm.userpass) {
    // 通过localStorage存储登录用户的信息
    const obj = { name: 'tom', photo: 'cat.jpg', token: '!!!@@@###' }
    // localStorage只能存储字符串，引入要使用JSON.stringify()做处理
    localStorage.setItem('userinfo', JSON.stringify(obj))

    // 路由编程导航到后台首页
    this.$router.push({ name: 'home' })
  }
}
```

> 模拟账户信息只有 name、photo、token 3样
>
> localStorage只能存储字符串，故要使用 JSON.stringify



### 展示用户信息

目标：

​	后台首页Home.vue头部展示用户信息



在views/Home.vue 中设置如下代码

```vue
<template>
  <div>
    <div id="head">
      <!-- 把账户的信息表现出来(name/photo/token),信息来自localStorage
            模板中不能直接操作localStorage，组件实例内部可以
       -->
       <p v-if="userinfo">
         用户名:{{userinfo.name}}----
         头像:{{userinfo.photo}}---
         秘钥:{{userinfo.token}}
       </p>
       <p v-else>
         未登录系统
       </p>
    </div>
    <div id="zhanghu"></div>
  </div>
</template>

<script>
export default {
  name: 'home',
  computed: {
    // 通过计算属性操作localStorage，进而获得登录账户的相关信息
    userinfo: function () {
      // 用户信息不一定存在，请灵活处理 str:试题字符串， str:null
      const str = localStorage.getItem('userinfo')
      if (str) {
        return JSON.parse(str)
      } else {
        return false
      }
    }
  }
}
</script>
```

> computed计算属性用于获得用户信息

效果：

![1581232598717](img(online)/1581232598717.png)

![1581232613658](img(online)/1581232613658.png)

### 账户组件应用

目标：

​	创建账户组件，可以实现 查看、修改 账户信息的两个功能



步骤：

1. 创建子组件 views/Account.vue，设置如下内容

   ```vue
   <template>
     <div>
       <span>对用户数据进行更新</span>
       <p v-if="userinfo">
         用户名：{{userinfo.name}}------
         头像：{{userinfo.photo}}-----
         秘钥：{{userinfo.token}}----
         <br />
         <button @click="up()">更新用户数据</button>
       </p>
       <p v-else>
         未登录系统
       </p>
     </div>
   </template>
   
   <script>
   export default {
     name: 'mod',
     computed: {
       // 通过计算属性操作localStorage，进而获得登录账户的相关信息
       userinfo: function () {
         // 用户信息不一定存在，请灵活处理 str:试题字符串， str:null
         const str = localStorage.getItem('userinfo')
         if (str) {
           return JSON.parse(str)
         } else {
           return false
         }
       }
     },
     methods: {
       up () {
         const obj = { name: 'jack', photo: 'dog.jpg', token: '$$$%%%^^^' }
         localStorage.setItem('userinfo', JSON.stringify(obj))
       }
     }
   }
   </script>
   
   <style lang="less" scoped>
   </style>
   
   ```

2. views/Home.vue 引入、注册、使用  Account.vue 组件

   ```vue
       <div id="zhanghu">
         <com-account></com-account>
       </div>
     </div>
   </template>
   
   <script>
   import ComAccount from './components/Account.vue'
   export default {
     name: 'home',
     components: {
       ComAccount
     },
   ```



现在后台首页展示效果：

![1581233182443](img(online)/1581233182443.png)

尴尬情况来了，单击 “更新用户数据” 按钮后，需要手动刷新，才会更新显示【之前应用的技术是兄弟组件传值达成同步更新】



## vuex介入

现在的问题是localStorage是浏览器技术，不是Vue的，其本身并没有“响应式”技术，故一个组件修改了用户信息后，另外一个组件并不能马上get(获得)到 (除非页面刷新)，现在就要使用vuex技术，实现多个组件之间共享数据、更新数据，还有响应式效果

vuex介入后的模式是：

- 用户组件操控vuex
- vuex操控localStorage

![1581149463667](img(online)/1581149463667.png)



`目标`：

​	用户组件通过vuex操作localStorage

​	(用户不要直接面对 localStorage)

​	

`步骤`：

1. 在 store/index.js中 创建state和mutations

   ```js
   // vuex操作localStorage
   // localStorage使用类型：获取、修改
   state: {
     // 配置用户账户信息成员
     user: JSON.parse(localStorage.getItem('userinfo'))
   },
     mutations: {
       // 修改用户信息
       updateUser: function (state, data) {
         // 1. vuex的共享数据要修改
         state.user = data
         // 2. localStorage数据要修改
         localStorage.setItem('userinfo', JSON.stringify(data))
       }
     },
   ```

2. Login.vue 通过vuex 存储用户信息

   ```js
   login () {
     if (this.loginForm.username && this.loginForm.userpass) {
       // 通过localStorage存储登录用户的信息
       const obj = { name: 'tom', photo: 'cat.jpg', token: '!!!@@@###' }
       // localStorage只能存储字符串，引入要使用JSON.stringify()做处理
       // localStorage.setItem('userinfo', JSON.stringify(obj))
       // 利用vuex维护用户信息
       this.$store.commit('updateUser', obj)
   
       // 路由编程导航到后台首页
       this.$router.push({ name: 'home' })
     }
   }
   ```

   

3. Home.vue 通过vuex获取用户信息

   ```js
     computed: {
       // 通过计算属性操作localStorage，进而获得登录账户的相关信息
       userinfo: function () {
         // 用户信息不一定存在，请灵活处理 str:试题字符串， str:null
         // const str = localStorage.getItem('userinfo')
         // if (str) {
         //   return JSON.parse(str)
         // } else {
         //   return false
         // }
         // 通过vuex获得用户信息
         return this.$store.state.user
       }
     }
   ```

   

4. Account.vue 通过vuex 获取、修改 用户信息

   ```js
     computed: {
       // 通过计算属性操作localStorage，进而获得登录账户的相关信息
       userinfo: function () {
         // 用户信息不一定存在，请灵活处理 str:试题字符串， str:null
         // const str = localStorage.getItem('userinfo')
         // if (str) {
         //   return JSON.parse(str)
         // } else {
         //   return false
         // }
         // 通过vuex获得用户信息
         return this.$store.state.user
       }
     },
     methods: {
       up () {
         const obj = { name: 'jack', photo: 'dog.jpg', token: '$$$%%%^^^' }
         // localStorage.setItem('userinfo', JSON.stringify(obj))
         // 通过vuex实现数据修改
         this.$store.commit('updateUser', obj)
       }
     }
   ```

   

`效果`：

![1581235379474](img(online)/1581235379474.png)

现在，一个组件对用户信息进行修改，其他组件**不用**f5刷新，就同步感知到了





案例总结：

组件： 

Login.vue   --> mutations---> 更新用户信息

Home.vue   ---> state ---> 获取展示用户信息

Account.vue ---> mutations/state ---> 展示/修改用户的信息

src/store/index.js

​	state: localStorage获得信息

​	mutations：修改信息  localStorage

操作模式：

用户组件--------(操作)------>Vuex--------------(操作)------------>localStorage



作业：

在vuex案例基础上新增一个业务组件，业务名称可以是个人中心(Person.vue)，与Account并列，本身要在Home.vue里边显示使用

内部通过vuex判断用户是否存在，存在-->显示“退出”按钮，不存在-->显示 “登录” 按钮

开发两个功能：

1. 用户不同状态显示不同信息(退出按钮、登录按钮)
2. 实现"退出"操作，通过vuex清除账号信息



