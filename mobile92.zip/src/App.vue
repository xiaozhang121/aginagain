<template>
  <div id="app">
    <router-view></router-view>
    <!-- <div id="pear" ></div> -->
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style lang="less" scoped>
// #pear{
//   width: 375px;
//   height:200px;
//   background-color:pink;
// }
</style>
