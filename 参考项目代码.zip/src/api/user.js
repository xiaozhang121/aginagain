// 用户相关的请求函数
import request from '@/utils/request' // 引入封装的模块

/**
 * 更新用户资料
 * @param {用户昵称} name
 * @param {用户性别} gender
 * @param {生日} birthday
 * 接口：【编辑用户个人资料（包含实名认证）】
 */
export function apiSaveProfile ({ name, gender, birthday }) {
  return request({
    url: '/app/v1_0/user/profile', // 编辑资料的地址
    data: {
      name,
      gender,
      birthday
    },
    method: 'patch'
  })
}

/**
 * 获取用户个人资料
 * 接口：【获取用户个人资料】
 */
export function apiUserProfile () {
  return request({
    url: '/app/v1_0/user/profile', // 地址
    method: 'get'
  })
}

/**
 * 上传用户头像
 * @param {FormData对象，拥有photo成员，代表被上传头像的文件对象} fdObj
 * 接口：【编辑用户照片资料（头像、身份证照片）】
 */
export function apiUserPhoto (fdObj) {
  return request({
    url: '/app/v1_0/user/photo', // 编辑头像的地址
    method: 'patch', // 设置头像的类型
    data: fdObj
  })
}

/**
 * api:获取用户自己信息
 * 接口文档的目标id 不用传->忽略
 * 接口：【获取用户自己信息】
 */
export const apiUserInfo = () => {
  return request({
    url: `/app/v1_0/user`,
    method: 'GET'
  })
}

/**
 * 关注作者
 * @param {target} 被关注用户id
 */
export function apiFollow (target) {
  return request({
    method: 'post',
    url: '/app/v1_0/user/followings',
    data: {
      target
    }
  })
}

/**
 * 取消关注作者
 * @param {target} 取消关注用户id
 */
export function apiUnFollow (target) {
  return request({
    method: 'delete',
    url: `/app/v1_0/user/followings/${target}`
  })
}

/**
 * 登录
 * @param {手机号码} mobile
 * @param {验证码} code
 * {mobile,code} 对象解构赋值，方便查看当前api需要哪个些参数
 */
export function apiUserLogin ({ mobile, code }) {
  // 返回一个promise对象  返回
  return request({
    url: '/app/v1_0/authorizations',
    data: {
      // 简易成员赋值
      mobile,
      code
    },
    method: 'post'
  })
}
