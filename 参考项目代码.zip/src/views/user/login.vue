<template>
  <div class="user-login">
    <van-nav-bar title="登录"></van-nav-bar>
    <van-cell-group>
      <ValidationObserver ref="loginFormRef">
        <ValidationProvider v-slot="{errors}" rules="required|phone" name="手机号码">
          <van-field
            v-model="loginForm.mobile"
            type="text"
            placeholder="请输入手机号码"
            label="手机号"
            required
            clearable
            :error-message="errors[0]"
          />
        </ValidationProvider>
        <ValidationProvider v-slot="{errors}" rules="required" name="验证码">
          <van-field
            v-model="loginForm.code"
            type="password"
            placeholder="请输入验证码"
            label="验证码"
            required
            clearable
            :error-message="errors[0]"
          >
            <van-button slot="button" size="small" type="primary">发送验证码</van-button>
          </van-field>
        </ValidationProvider>
      </ValidationObserver>
    </van-cell-group>
    <div class="login-btn">
      <van-button
        type="info"
        size="small"
        round
        block
        @click="login()"
        :loading="isLogin"
        loading-text="登录中..."
      >登录</van-button>
    </div>
  </div>
</template>

<script>
import { apiUserLogin } from '@/api/user'
import { mapMutations } from 'vuex'
// 验证相关模块导入
import { ValidationProvider, ValidationObserver } from 'vee-validate'
export default {
  name: 'user-login',
  components: {
    ValidationProvider,
    ValidationObserver
  },
  data () {
    return {
      isLogin: false, // 登录等待
      // 表单数据对象
      loginForm: {
        mobile: '13911111111',
        code: '246810'
      }
    }
  },
  methods: {
    // 对vuex的mutations方法进行展开操作
    ...mapMutations(['updateUser']),
    async login () {
      // 表单校验
      let valid = await this.$refs.loginFormRef.validate()
      if (!valid) {
        return false // 校验失败停止后续代码执行
      }
      this.isLogin = true // 开启等待效果
      try {
        let result = await apiUserLogin(this.loginForm)
        // Vuex实现token等信息的存储管理
        this.updateUser(result)
        this.$toast.success('登录成功')

        let { redirectUrl } = this.$route.query // 接收会跳地址
        this.$router.push(redirectUrl || '/') // 判断是否有会跳地址要执行
      } catch (err) {
        return this.$toast.fail('账号ddd不正确')
      }
      this.isLogin = false // 关闭等待效果
    }
  }
}
</script>

<style scoped lang='less'>
.login-btn {
  margin: 40px;
}
</style>
