<template>
  <div class="container">
    <van-nav-bar title="搜索中心" left-arrow @click-left="$router.back()"/>
    <!-- 检索输入框 -->
    <van-search
      v-model="searchText"
      placeholder="请输入搜索关键词"
      @clear="onClear"
      @search="onSearch(searchText)"
    />
    <van-cell-group v-if="sugguestionList.length>0">
      <!--展示联想内容-->
      <van-cell
        :title="item"
        icon="search"
        v-for="(item,k) in sugguestionList"
        :key="k"
        @click="onSearch(item)"
      >
        <!-- 关键字高亮 -->
        <div slot="title" v-html="highlightCell(item,searchText)"></div>
      </van-cell>
    </van-cell-group>
    <van-cell-group v-else>
      <!-- 联想历史记录管理 -->
      <van-cell title="历史记录">
        <van-icon
          @click="isDeleteData=true"
          v-show="!isDeleteData"
          slot="right-icon"
          name="delete"
          style="line-height:inherit"
        ></van-icon>
        <div v-show="isDeleteData">
          <span style="margin-right:10px" @click="delAllSugguest()">全部删除</span>
          <span @click="isDeleteData=false">完成</span>
        </div>
      </van-cell>
      <!--联想建议历史记录项目-->
      <van-cell :title="item" v-for="(item,k) in sugguestHistories" :key="k">
        <!-- 删除按钮 -->
        <van-icon v-show="isDeleteData" slot="right-icon" name="close" style="line-height:inherit" @click="delSugguest(k)"></van-icon>
      </van-cell>
    </van-cell-group>
  </div>
</template>

<script>
// 导入api函数
import { apiSuggestionList } from '@/api/search'
export default {
  name: 'search-index',
  watch: {
    searchText (newV) {
      // 每次执行时，就清除之前的定时器，以保证定时器不会重复累加
      clearTimeout(this.timer)

      this.timer = setTimeout(async () => {
        let txt = newV.trim() // 去除左右空格
        if (!txt) {
          this.sugguestionList = []
          return false
        }

        // 进行搜索
        let result = await apiSuggestionList({ q: txt })
        this.sugguestionList = result.options
      }, 1000)
    }
  },
  data () {
    return {
      // 联想建议 本地localStorage 的key的名称
      histroyKey: 'sugguest-histories',
      // 联想历史记录
      sugguestHistories: JSON.parse(localStorage.getItem('sugguest-histories')) || [],

      isDeleteData: false, // 历史记录开关
      sugguestionList: [], // 联想到的数据
      searchText: '' // 搜索关键字
    }
  },
  methods: {
    // 删除“全部”联想建议历史记录
    delAllSugguest () {
      this.sugguestHistories = []
      localStorage.removeItem(this.histroyKey)
    },
    // 删除“单个”的联想建议历史记录
    delSugguest (index) {
      this.sugguestHistories.splice(index, 1)
      // 更新localStorage数据
      localStorage.setItem(this.histroyKey, JSON.stringify(this.sugguestHistories))
    },
    // 根据关键字检索文章
    onSearch (keywords) {
      keywords = keywords.trim()
      // 没有联想内容，停止后续处理
      if (!keywords) { return false }

      let data = new Set(this.sugguestHistories) // 根据已有的历史记录创建Set对象
      data.add(keywords) // 存储访问的关键字
      this.sugguestHistories = Array.from(data) // 把添加好的整体历史记录变为Array数组
      // 把联想关键字数组存储给localStorage里边(名称为sugguest-histories)
      window.localStorage.setItem(this.histroyKey, JSON.stringify(this.sugguestHistories))

      // 路由编程式导航，进入搜索文章展示页面
      this.$router.push({ name: 'result', params: { q: keywords } })
    },
    // 搜索关键字高亮
    highlightCell (item, keywords) {
      let reg = new RegExp(`${keywords}`, 'i') // 正则，忽略大小写
      let rst = item.match(reg) // 获得到匹配内容

      // 对关键字进行高亮处理
      return item.replace(reg, `<span style="color:red">${rst[0]}</span>`)
    },
    // 清除搜索内容
    onClear () {
      this.sugguestionList = []
    }
  }
}
</script>

<style lang="less" scoped>
</style>
