<template>
  <van-dialog
    :value="value"
    :show-confirm-button="false"
    @input="$emit('input')"
    close-on-click-overlay
  >
    <van-cell-group v-if="!isReportShow">
      <van-cell icon="location-o" title="不感兴趣" @click="articleDislike()"/>
      <van-cell icon="location-o" title="反馈垃圾内容" is-link @click="isReportShow=true"/>
      <van-cell icon="location-o" title="拉黑作者"/>
    </van-cell-group>

    <van-cell-group v-else>
      <van-cell icon="arrow-left" @click="isReportShow=false"/>
      <van-cell
        v-for="item in reportsList"
        :key="item.value"
        :title="item.title"
        icon="location-o"
        @click="articleReport(item.value)"
        />
    </van-cell-group>
  </van-dialog>
</template>

<script>
import { apiArticleDislike, apiArticleReport } from '@/api/article'
export default {
  name: 'ComMoreAction',
  props: {
    // 接收父传递过来的信息
    value: {
      type: Boolean,
      default: false
    },
    // 不喜欢文章的id
    articleID: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      // 举报类型：
      reportsList: [
        { title: '其他问题', value: 0 },
        { title: '标题夸张', value: 1 },
        { title: '低俗色情', value: 2 },
        { title: '错别字多', value: 3 },
        { title: '旧闻重复', value: 4 },
        { title: '广告软文', value: 5 },
        { title: '内容不实', value: 6 },
        { title: '涉嫌违法犯罪', value: 7 },
        { title: '侵权', value: 8 }
      ],
      isReportShow: false // 是否展示 “反垃圾内容” 子级
    }
  },
  methods: {
    /**
     * 对文章做举报处理
     */
    async articleReport (type) {
      try {
        await apiArticleReport({ articleID: this.articleID, type: type })
      } catch (err) {
        this.$emit('input', false) // 关闭弹框
        if (err.response.status === 409) {
          this.$toast.fail('文章已经被举报过')
        } else {
          this.$toast.fail('举报失败')
        }
        return false
      }
      // 举报成功处理
      this.$emit('input', false) // 关闭弹框
      this.$toast.fail('举报成功！')
    },
    /**
     * 对不感兴趣文章做处理
     */
    async articleDislike () {
      let result = await apiArticleDislike(this.articleID)
      if (!result.target) {
        this.$toast.fail('不感兴趣操作失败')
        return false
      }

      // 刷新文章列表
      this.$emit('dislikeSuccess')
      // 关闭弹框
      this.$emit('input', false)
      // 成功提示
      this.$toast.success('操作成功')
    }
  }
}
</script>
