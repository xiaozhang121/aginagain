<template>
  <!-- 文章列表展示区域 -->
  <div class="scroll-wrapper">
    <!-- B.下拉刷新组件 -->
    <van-pull-refresh
      v-model="isLoading"
      @refresh="onRefresh"
      :success-text="downSuccessText"
      :success-duration="1000"
    >
      <!-- 文章上拉列表 -->
      <!-- A. 上拉刷新 -->
      <van-list v-model="loading" :finished="finished" finished-text="没有更多了" @load="onLoad">
        <van-cell v-for="item in articleList" :key="item.art_id.toString()">
          <span
            slot="title"
            @click="$router.push({name:'article',params:{aid:item.art_id.toString()}})"
          >{{item.title}}</span>
          <template slot="label">
            <van-grid :border="false" v-if="item.cover.type>0" :column-num="item.cover.type">
              <van-grid-item
                v-for="(item2,k2) in item.cover.images"
                :key="k2"
                @click="$router.push({name:'article',params:{aid:item.art_id.toString()}})"
              >
                <van-image width="90" height="90" :src="item2" lazy-load/>
              </van-grid-item>
            </van-grid>
            <p>
              <van-icon
                name="close"
                style="float:right;"
                @click="displayDialog(item.art_id.toString())"
              />
              <span>作者:{{item.aut_name}}</span>
              &nbsp;
              <span>评论 :{{item.comm_count}}</span>
              &nbsp;
              <span>时间:{{item.pubdate | formatTime}}</span>
              &nbsp;
            </p>
          </template>
        </van-cell>
      </van-list>
    </van-pull-refresh>
    <!--关闭-更多动作弹出框-->
    <more-action
      v-model="showDialog"
      :articleID="nowArticleID"
      @dislikeSuccess="handleDislikeSuccess"
    ></more-action>
  </div>
</template>

<script>
import MoreAction from './com-moreaction'
import Vue from 'vue'
import { Lazyload } from 'vant'
// 获取文章
import { apiArticleList } from '@/api/article'
Vue.use(Lazyload) // 图片懒加载

export default {
  name: 'com-article',
  components: {
    MoreAction
  },
  props: {
    // 当前选中的频道id信息
    channel_id: {
      type: Number,
      required: true
    }
  },
  data () {
    return {
      downSuccessText: '', // 下拉成功的提示信息
      nowArticleID: '', // 不感兴趣文章id
      showDialog: false, // 弹出框
      // 声明一个时间戳成员，用于获取文章使用
      ts: Date.now(),
      // 当前频道文章列表信息
      articleList: [],
      // 下拉刷新标志
      isLoading: false,
      // 上拉相关成员
      list: [],
      loading: false,
      finished: false
    }
  },
  methods: {
    /**
     * 不感兴趣文章的后续成功处理
     */
    handleDislikeSuccess () {
      // 获取当前被处理文章在数组中下标
      let index = this.articleList.findIndex(
        item => item.art_id.toString() === this.nowArticleID
      )
      // 在总的文章中把当前文章清除掉
      this.articleList.splice(index, 1)
    },
    /**
     * 显示更多操作对话框
     * artID: 不喜欢文章id
     */
    displayDialog (artID) {
      this.showDialog = true
      this.nowArticleID = artID
    },
    // 获得文章列表
    async getArticleList () {
      let result = await apiArticleList({
        channel_id: this.channel_id,
        timestamp: this.ts,
        with_top: 1
      })
      // // data接收获取的文章(变为追加状态)
      // this.articleList.push(...result.results)
      // // 更新时间戳信息
      // this.ts = result.pre_timestamp

      return result
    },
    // 下拉刷新载入
    async onRefresh () {
      await this.$sleep(1000) // 暂停1s

      // 获取文章信息
      let result = await this.getArticleList()

      if (result.results.length) {
        // 把文章追加给articleList
        this.articleList.unshift(...result.results)
        this.downSuccessText = '加载最新文章成功'
        // 更新时间戳
        this.ts = result.pre_timestamp
      } else {
        this.downSuccessText = '已经是最新文章'
      }
      this.isLoading = false // 暂停拉取
    },
    // 上拉刷新载入
    async onLoad () {
      await this.$sleep(800) // 暂停0.8秒

      let result = await this.getArticleList()

      // 把文章追加给articleList
      this.articleList.push(...result.results)
      // 关闭加载状态
      this.loading = false
      if (!result.pre_timestamp) {
        // 停止上拉载入功能
        this.finished = true
      } else {
        this.ts = result.pre_timestamp
      }
    }
  }
}
</script>

<style lang="less" scoped>
// 给上拉列表设置样式
.scroll-wrapper {
  height: 100%;
  overflow-y: auto;
}
</style>
