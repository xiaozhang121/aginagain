<template>
  <van-popup
    :value="value"
    @input="$emit('input')"
    closeable
    close-icon-position="top-left"
    round
    position="bottom"
    :style="{ height: '95%' }"
  >
    <div class="channel">
      <div class="channel-head">
        <div>
          <span class="title">我的频道</span>
          <span class="desc">点击进入频道</span>
        </div>
        <div>
          <van-button type="danger" plain size="mini" round @click="isEdit=!isEdit">
            {{isEdit?'完成':'编辑'}}
          </van-button>
        </div>
      </div>
      <van-grid class="channel-content" :gutter="10" clickable>
        <van-grid-item v-for="(item,k) in channelList" :key="item.id"
          @click="clkChannel(item.id,k)">
          <span class="text" :style="{color:k===activeChannelIndex?'red':''}">
            {{item.name}}
          </span>
          <!-- 删除我的频道图标 -->
          <van-icon class="close-icon" name="close"
            v-show="isEdit && k!==0" @click="userToRest(item.id,k)"/>
        </van-grid-item>
      </van-grid>
    </div>

    <div class="channel">
      <div class="channel-head">
        <div>
          <span class="title">频道推荐</span>
          <span class="desc">点击添加频道</span>
        </div>
      </div>
      <van-grid class="channel-content" :gutter="10" clickable>
        <van-grid-item v-for="item in channelRest" :key="item.id" @click="restToUser(item)">
          <div class="info">
            <span class="text">{{item.name}}</span>
          </div>
        </van-grid-item>
      </van-grid>
    </div>
  </van-popup>
</template>

<script>
import { apiChannelAll, apiChannelAdd, apiChannelDel } from '@/api/channel'
export default {
  name: 'ComChannel',
  computed: {
    // 从 全部频道 数据里边过滤掉 我的频道
    channelRest: function () {
      // 把“我的频道”的全部id获得到，通过Array
      let userChannelIds = this.channelList.map(item => {
        return item.id
      })
      // 遍历全部频道，返回不在“我的频道”出现的频道
      let rest = this.channelAll.filter(item => {
        // Array.includes判断是否包含该元素
        return !userChannelIds.includes(item.id)
      })
      // 返回过滤好的剩余的频道
      return rest
    }
  },
  props: {
    value: {
      type: Boolean,
      default: false
    },
    // 我的频道
    channelList: {
      type: Array,
      // 通过箭头函数实现设置空数组默认值效果
      default: () => []
    },
    // 当前激活频道
    activeChannelIndex: {
      type: Number,
      default: 0
    }
  },
  data () {
    return {
      isEdit: false, // 是否进入编辑状态
      channelAll: [] // 全部频道
    }
  },
  created () {
    this.getChannelAll()
  },
  methods: {
    // 激活频道(兼顾删除)
    // channelID: 被单击频道的id
    // index:被激活频道的下标
    clkChannel (channelID, index) {
      if (this.isEdit && index !== 0) {
        // 删除频道逻辑
        this.userToRest(channelID, index)
        return false
      }
      // 根据index激活home主页面的频道
      // 如下用法：表示对当前组件名称为 activeChannelIndex 的项目信息进行修改
      // activeChannelIndex 是home中设置sync调用那个项目
      // 即子组件要修改父组件数据
      this.$emit('update:activeChannelIndex', index)
      // 关闭弹出层
      this.$emit('input', false)
    },
    // 删除频道
    // channelID:被删除频道的id
    // index:被删除频道的下标序号
    userToRest (channelID, index) {
      this.channelList.splice(index, 1) // 页面删除
      apiChannelDel(channelID)// 持久删除

      // 判断当前被删除频道如果是最后一个，就把激活项目的下标序号向前移动一位
      // 是修改父组件的activeChannelIndex
      if (this.channelList.length === index) {
        this.$emit('update:activeChannelIndex', this.activeChannelIndex - 1)
      }
    },
    // 添加频道
    restToUser (channel) {
      // channelList虽然是父给子传递的，但是这是数组，是引用传递来的
      // 因此子页面修改了，父页面会自动感知到
      this.channelList.push(channel)
      // 持久化存储频道
      apiChannelAdd(channel)
    },
    // 获取全部频道
    async getChannelAll () {
      let result = await apiChannelAll()
      this.channelAll = result.channels
    }
  }
}
</script>

<style lang="less" scoped>
.channel {
  margin-top:70px;
  .channel-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px;
    .title {
      font-size: 30px;
      margin-right: 5px;
    }
    .desc {
      font-size: 16px;
      color:gray;
    }
  }
  .channel-content {
    .text {
      font-size: 16px;
    }
    .active {
      color: red;
    }
    .close-icon {
      font-size: 20px;
      position: absolute;
      top: -5px;
      right: -5px;
      z-index: 999;
      background-color: #fff;
    }
    .info {
      display: flex;
      align-items: center;
    }
  }
}
</style>
