import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

import Vant from 'vant'
import 'vant/lib/index.css'
import '@/assets/css/global.less' // 引入全局的自定义样式  因为要覆盖vant的样式
import 'amfe-flexible/index.min.js'

import '@/utils/validate' // 验证相关

import * as filters from '@/utils/filters' // 过滤器

// 注册全局过滤器
Object.keys(filters).forEach(item => {
  Vue.filter(item, filters[item])
})

Vue.use(Vant)

Vue.config.productionTip = false

Vue.prototype.$sleep = time => {
  return new Promise((resolve) => {
    window.setTimeout(() => {
      resolve()
    }, time)
  })
}

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
