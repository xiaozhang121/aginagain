import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    component: () => import('@/views/layout'), // 布局组件  一级路由
    children: [
      {
        path: '/',
        component: () => import('@/views/home') // 二级路由 首页
      },
      {
        path: '/question',
        component: () => import('@/views/question') // 二级路由 问答组件
      },
      {
        path: '/video',
        component: () => import('@/views/video') // 二级路由 视频组件
      },
      {
        path: '/user',
        component: () => import('@/views/user') // 二级路由 个人中心
      }
    ]
  },
  {
    path: '/user/profile',
    component: () => import('@/views/user/profile') // 编辑资料
  },
  {
    path: '/user/chat',
    component: () => import('@/views/user/chat') // 小智同学
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('@/views/user/login') // 登录组件
  },
  {
    path: '/article/:aid',
    name: 'article',
    component: () => import('@/views/article') // 文章详情
  },
  {
    path: '/search',
    component: () => import('@/views/search') // 搜索中心
  },
  {
    path: '/search/result/:q',
    name: 'result',
    component: () => import('@/views/search/result.vue') // 搜索结果
  }
]

const router = new VueRouter({
  routes
})

// // 配置全局前置路由守卫
// router.beforeEach((to, from, next) => {
//   // 获得用户登录状态信息
//   let tokeninfo = store.state.user

//   // 登录状态：tokeninfo是大字符串， 非登录状态，tokeninfo是null
//   if (!tokeninfo.token && to.path !== '/login') {
//     // 强制登录
//     return next('/login')
//   }

//   // 放行
//   next()
// })

export default router
