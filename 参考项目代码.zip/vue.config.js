module.exports = {
  lintOnSave: false,
  devServer: {
    open: true,
    port: 33355
  }
}
